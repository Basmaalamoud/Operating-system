/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osproject;


import java.util.Scanner;

/**
 *
 * @author User
 */
public class OSproject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner s=new Scanner(System.in);
        PPS pps=null;
        int choice;
        do{
            System.out.println("**********************");
            System.out.println("1. Enter process’ information.");
            System.out.println("2. Report detailed information about each process and different scheduling criteria.");
            System.out.println("3. Exit the program.");
            choice=s.nextInt();
            switch(choice){
                case 1:
                    pps=new PPS();
                    pps.algorithm();
                    break;
                case 2:
                    if(pps==null)
                        continue;
                    
                    pps.printOutput();
                    pps.toFile();
                    break;
                 
            }
        }while(choice!=3);
       
    }
    
}
