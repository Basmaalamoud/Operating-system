/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osproject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class PPS {
    //store the processes that not arrived to ready queue yet
    ArrayList<Process> initProcess;//فيها البروسسات الابتدائيه
    //store the processes that executed
    ArrayList<Process> completeProcess;//نحط الي كملوا عشان نطبعهم
    PriorityQueue<Process> readyQueue;//نحط الي تنتظربالترتيب
    //store ids of processes that enter in cpu ,-1 is SC ,-2 is complete 
    ArrayList<Integer> scheduling;//نخزن الايديز اذا سالب واحد سكجول اذا سالب ثنين خلصت
    //store the time of processes entering the cpu 
    ArrayList<Double>schedulingTime;//مقابل كل بروس خزنها وقتها
    //cuurent executing process
    Process executingProcess;//نشتغل عليها حاليا
    //current time
    double time;//الوقت الحالي كل الوقت الي سوت فيه كومبليت

    public PPS() {
        //input info of process from user 
        Scanner scanner=new Scanner(System.in);
        initProcess=new ArrayList<>();
        completeProcess=new ArrayList<>();
        readyQueue=new PriorityQueue<>();
        scheduling=new ArrayList<>();
        schedulingTime=new ArrayList<>();
        executingProcess=null;
        time=0;
        int n,priority;
        double arrive,cpuBurst;
        System.out.println("Enter number of process:");
        n=scanner.nextInt();
        for (int ID = 1; ID <= n; ID++) {
            System.out.println("Process "+ID+" :");
            System.out.print("priority= ");
            priority=scanner.nextInt();
            System.out.print("arrive time= ");
            arrive=scanner.nextDouble();
            System.out.print("cpu burst= ");
            cpuBurst=scanner.nextDouble();
            initProcess.add(new Process(ID, priority, arrive, cpuBurst));
        }
    }
    
    public void algorithm(){
      double deltaTime;
        while (!initProcess.isEmpty()||!readyQueue.isEmpty()||executingProcess!=null) {//اذا فاضين ما ندخل الللوب  
            //get delta time to next stop(process arrive or executing prcess done
            deltaTime=getDeltaTime();//متى وقف
            //update time and timeToComplete of executing process with delta time
            executeDeltaTime(deltaTime);
            //check if executing process is done 
            complete();
            //check if processes in initProcess arrive in current time and added them to ready queue
            addArriveProcess();
            //check if best priority process in ready queue will enter the cpu
            schedule();
        }
        //add complete 
        scheduling.add(-2);//كومبليت
        schedulingTime.add(time);//الوقت الي خلص فيه
    }
    
    //function to calcultae time to next step
    //next step is process arrive or current executing process done
    private double getDeltaTime(){//وقت التوقف القادم
        //find first process will arrive 
        double firstProcessArriveTime=Double.MAX_VALUE;
        for (Process ip : initProcess) {
            firstProcessArriveTime=Math.min(ip.getArrive(), firstProcessArriveTime);//يا البرووسس الي بتجي او البرووس الي بدينا فيه وبتخلص 
        }
        //calculate delta time to arrive
        double deltaTime=firstProcessArriveTime-this.time;//يطرح من اصغر وحدة الوقت الحالي عشان يطلع اخر وقت يبدا فيه الثاني 
        //calculate delta time to current executing process done
        if(this.executingProcess!=null)
            deltaTime=Math.min(deltaTime, this.executingProcess.getTimeToComplete());
        //return min of both
        return deltaTime;
    }
    private void executeDeltaTime(double dt){
        //update time
        this.time+=dt;
        if(this.executingProcess!=null)
            //update timeToComplete to current executing process
            this.executingProcess.execute(dt);
    }
    
    private void complete(){
        //check if has process executing
        if(this.executingProcess!=null){
            //check if current executing process don
            if(executingProcess.isComplete()){
                
                executingProcess.setEnd(time);
                executingProcess.calcultaeOtherTimes();
                completeProcess.add(executingProcess);
                executingProcess=null;//ترمنشين المعالج فاضي
            }
        }
    }
    
    private void addArriveProcess(){
        for (int i = 0; i < initProcess.size(); i++) 
        {
            if(initProcess.get(i).hasArrive(time)){
                readyQueue.add(initProcess.get(i));
                 initProcess.remove(i);//اشيلها من الانشال
                i--;
            }
        }
    }
    //this method check if one process will enter the cpu 
    private void schedule(){
        //ready queue empty 
        if(readyQueue.isEmpty())//الحاله الاولى
            return;
       
        if(executingProcess==null){ //no process in cpu حاله ثانيه
            //add SC to scheduling chart
            if(!scheduling.isEmpty()){//اذا مو فاضي ادخل
              scheduling.add(-1);
                schedulingTime.add(time);
                time++;  
            }
            //get best priority process from ready queue and execute it
            executingProcess=readyQueue.poll();
            //add id to scheduling chart
            scheduling.add(executingProcess.getID());//هذي نشتغل عليها
            schedulingTime.add(time);
            //set start time if this is first time enter the cpu
            if(!executingProcess.hasStart())
            executingProcess.setStart(time);
        }
        else {//there is process executing
            if(readyQueue.peek().getPriority()<executingProcess.getPriority()){//check if process with better priority arrive
                
                Process temp=executingProcess;//حفظ الي وقفناها
                //enter new process to cpu
                executingProcess=readyQueue.poll();//الجديد الي اخذتها من الردي كيو
                //return last process to ready queue
                temp.setLastArrive(time);
                readyQueue.add(temp);
                scheduling.add(-1);//add SC to scheduling chart
                schedulingTime.add(time);
                time++;
                if(!executingProcess.hasStart()) //set start time if this is first time enter the cpu
                    executingProcess.setStart(time);//دخلت الجديده اذا ما بدت خلها تبدا
                //add id to scheduling chart
                scheduling.add(executingProcess.getID());// احط الايدي الجديده بالسكجول
                schedulingTime.add(time);
            }
        }
    }
//convert scheduling chart to string 
    private String schedulingToString() {
        String s="";
       s+="[";
        for (int i=0;i<scheduling.size();i++) {
           int pId=scheduling.get(i);
           double t=schedulingTime.get(i);
            if(pId==-1){//تجتاج سكاجوال
                s+="CS:"+t+"|";
            }
            else  if(pId==-2){//خلصت
                s+="Complete:"+t;
            }
            else 
                s+="P"+pId+":"+t+"|";
        }
        s+="]";
    return s;
    }
    
    private double calculateTurnAroundTimeAverage(){
        double sum=0;
        for (Process cp : completeProcess) {
            sum+=cp.getTernAround();
        }
        return sum/completeProcess.size();
    }
    private double calculateWaitingTimeAverage(){
        double sum=0;
        for (Process cp : completeProcess) {
            sum+=cp.getWaiting();
        }
        return sum/completeProcess.size();
    }
    private double calculateResponseTimeAverage(){
        double sum=0;
        for (Process cp : completeProcess) {
            sum+=cp.getResponse();
        }
        return sum/completeProcess.size();
    }
    //print output on console
    public void printOutput(){
        
        for (Process cp : this.completeProcess) {
            System.out.println(cp.inputToString());
            System.out.println(cp.outputToString());
            System.out.println("-----------------------------");
        }
        System.out.println(schedulingToString());
        System.out.println("-----------------------------");
        System.out.println("Turn around time average:"+calculateTurnAroundTimeAverage());
        System.out.println("Waiting time average: "+calculateWaitingTimeAverage());
        System.out.println("Respose time average: "+calculateResponseTimeAverage());

    }
    //print output on file
    public void toFile(){
        try {
            BufferedWriter bufferedWriter=new BufferedWriter(new FileWriter(new File("Report.txt")));
            for (Process cp : this.completeProcess) {
            bufferedWriter.write(cp.inputToString());
            bufferedWriter.newLine();
            bufferedWriter.write(cp.outputToString());
             bufferedWriter.newLine();
            bufferedWriter.write("-----------------------------");
             bufferedWriter.newLine();
        }
        bufferedWriter.write(schedulingToString());
         bufferedWriter.newLine();
                     bufferedWriter.write("-----------------------------");
             bufferedWriter.newLine();
        bufferedWriter.write("Turn around time average:"+calculateTurnAroundTimeAverage());
         bufferedWriter.newLine();
        bufferedWriter.write("Waiting time average: "+calculateWaitingTimeAverage());
         bufferedWriter.newLine();
        bufferedWriter.write("Respose time average: "+calculateResponseTimeAverage());
         bufferedWriter.newLine();
            bufferedWriter.close();
        } catch (IOException ex) {
            Logger.getLogger(PPS.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
