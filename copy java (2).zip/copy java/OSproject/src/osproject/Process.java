/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package osproject;

/**
 *
 * @author User
 */
//class to store info of one process 
public class Process implements Comparable<Process>{
   private int ID,priority;
   private double arrive,cpuBurst,start,end,ternAround,waiting,response,timeToComplete,outFromCpu;
//timeToComplete نفس البرست لكن يقل مع الوقت كل ما كملت جزء
   //outFromCpu يكون صفر يعني ماقد دخلت واحد سبق ودخلت
    public Process(int ID, int priority, double arrive, double cpuBurst) {//ياخذ الانبوت 
        this.ID = ID;
        this.priority = priority;
        this.arrive = arrive;
        this.cpuBurst = cpuBurst;
        //in the begin timeToCpmlete equal to cpu burst and when execute process it redus to 0
        this.timeToComplete = cpuBurst;
        this.outFromCpu=0;//اذا دخلت المعالج اعطيها واحد
        //when start time equal -1 that mean it is not set yet 
        this.start=-1;//اذا ضلت سالب واحد يعني مادخات المعاج
    }

    public void setStart(double start) {
        this.start = start;
    }

    public void setEnd(double end) {
        this.end = end;
    }
    void calcultaeOtherTimes(){//
        this.ternAround=end-arrive;//الفرق بين الدخول والخروج 
        this.waiting=ternAround-cpuBurst;//يحسب الوقت الي انتظرته في الكيو قبل المعالجه
        response=this.start-this.arrive;//وقت الدحول ناقص وقت وصولها
    }

    public int getID() {
        return ID;
    }
    public String inputToString(){
        return "ID: "+ID+"  Priority: "+priority+"  Arrive time: "+arrive+" CPU burst: "+cpuBurst;
    }
    public String outputToString(){
        return "Start time: "+start+"  End time: "+end+"  Turn around time: "
                +ternAround+" Waiting time: "+waiting+"  Response time: "+response;
    }
    
    public boolean hasArrive(double time){//يشوف وصلت او لا
        return this.arrive<=time;
    }
    
    public void execute(double time){//عشان اعرف كم بقى وكل شوي انقص
        this.timeToComplete-=time;
    }

    public double getCpuBurst() {
        return cpuBurst;
    }

    public double getTimeToComplete() {
        return timeToComplete;
    }

    public double getArrive() {
        return arrive;
    }
    public boolean isComplete(){//هل تساوي صفر يعني خلصت او لا
        return timeToComplete<=0;
    }

    public int getPriority() {
        return priority;
    }

    public boolean hasStart() {//اذا رجعت غير سالب واحد يعني بدت
        return start!=-1;
    }

    public double getTernAround() {
        return ternAround;
    }

    public double getWaiting() {
        return waiting;
    }

    public double getResponse() {
        return response;
    }

    public void setLastArrive(double lastArrive) {//لما اطلعها من المعالج احطها بالردي كيو
        this.outFromCpu = lastArrive;
    }
    
    
    
    @Override
    public int compareTo(Process t) {//هنا عالجنا فرس كمفرست سرف عند الارايف 
        if(this.priority!=t.priority)
            return Integer.compare(priority, t.priority);
        if(this.outFromCpu!=t.outFromCpu)
            return Double.compare(outFromCpu, t.outFromCpu);
        if(this.arrive!=t.arrive)
            return Double.compare(arrive, t.arrive);
        return Integer.compare(ID, t.ID);
    }
    
    
}
